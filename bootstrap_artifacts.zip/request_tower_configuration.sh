#!/bin/bash

fatal() {
  if [ -n "${2}" ]; then
    echo -e "Error: ${2}"
  fi
  exit ${1}
}

usage() {
cat << EOF
Usage: $0 <options>

Request server configuration from Ansible Tower.

OPTIONS:
   -h      Show this message
   -s      Tower server (e.g. https://tower.example.com) (required)
   -k      Allow insecure SSL connections and transfers
   -c      Host config key (required)
   -t      Job template ID (required)
   -e      Extra variables
EOF
}

# Initialize variables
INSECURE=""
CURL_H_VARS="''"

# Parse arguments
while getopts “hks:c:t:s:e:a:” OPTION
do
  case ${OPTION} in
    h)
      usage
      exit 1
      ;;
    s)
      TOWER_SERVER=${OPTARG}
      ;;
    k)
      INSECURE="-k"
      ;;
    c)
      HOST_CFG_KEY=${OPTARG}
      ;;
    t)
      TEMPLATE_ID=${OPTARG}
      ;;
    e)
      EXTRA_VARS=${OPTARG}
      ;;
    a)
      CURL_H_VARS=${OPTARG}
      ;;
    ?)
      usage
      exit
      ;;
  esac
done

# Validate required arguments
test -z ${TOWER_SERVER} && fatal 1 "Missing required -s argument"
[[ "${TOWER_SERVER}" =~ ^https?:// ]] || fatal 1 "Tower server must begin with http:// or https://"
test -z ${HOST_CFG_KEY} && fatal 1 "Missing required -c argument"
test -z ${TEMPLATE_ID} && fatal 1 "Missing required -t argument"

# Generate curl --data parameter
if [ -n "${EXTRA_VARS}" ]; then
  CURL_DATA="{\"host_config_key\": \"${HOST_CFG_KEY}\", \"extra_vars\": \"${EXTRA_VARS}\"}"
else
  CURL_DATA="{\"host_config_key\": \"${HOST_CFG_KEY}\"}"
fi

# Success on any 2xx status received, failure on only 404 status received, retry any other status every min for up to 10 min
RETRY_ATTEMPTS=10
ATTEMPT=0
while [[ ${ATTEMPT} -lt ${RETRY_ATTEMPTS} ]]
do
  set -o pipefail
  
  echo "Trying ${ATTEMPT} of ${RETRY_ATTEMPTS}..."
  echo curl ${INSECURE} -s -i -X POST -H ${CURL_H_VARS} -H 'Content-Type:application/json' --data "$CURL_DATA" ${TOWER_SERVER}/api/v2/job_templates/${TEMPLATE_ID}/callback/

  # curl ${INSECURE} -s -i -X POST -H ${CURL_H_VARS} -H 'Content-Type:application/json' --data "$CURL_DATA" ${TOWER_SERVER}/api/v2/job_templates/${TEMPLATE_ID}/callback/ > /tmp/c.out 2>&1
  CURL_CMD_OUTPUT=$(curl ${INSECURE} -s -k -i -X POST -H ${CURL_H_VARS} -H 'Content-Type:application/json' --data "$CURL_DATA" ${TOWER_SERVER}/api/v2/job_templates/${TEMPLATE_ID}/callback/ 2>&1 | tr -d '\r')
  CURL_RC=$?  
  # CURL_CMD_OUTPUT=`cat /tmp/c.out | tr -d '\r'`
  if [ ${CURL_RC} -ne 0 ]; then
    echo "Error: RC=${CURL_RC} Command output: ${CURL_CMD_OUTPUT}"
    fatal ${CURL_RC} "curl exited with ${CURL_RC}, halting."
  fi

  HTTP_STATUS=`echo ${CURL_CMD_OUTPUT} | head -n1 | awk '{print $2}'`
  if [[ ${HTTP_STATUS} =~ ^2[0-9]+$ ]]; then
    JOB_URL=`echo ${CURL_CMD_OUTPUT} | grep -oP "Location: \K.*" | cut -d" " -f1`
    echo "HTTP_STATUS=${HTTP_STATUS} JOB_URL=${JOB_URL}"
    break
  elif [[ ${HTTP_STATUS} =~ ^404$ ]]; then
    echo "Error: HTTP_STATUS=${HTTP_STATUS} Command output: ${CURL_CMD_OUTPUT}"
    fatal 1 "Failed: ${HTTP_STATUS} received, encountered problem, halting."
  else
    ATTEMPT=$((ATTEMPT + 1))
    echo "Failed: ${HTTP_STATUS} received, executing retry #${ATTEMPT} in 1 minute."
    echo "Error: HTTP_STATUS=${HTTP_STATUS} Command output: ${CURL_CMD_OUTPUT}"
    echo "Trying again in 60 seconds..."
    sleep 60
  fi
done

if [[ $JOB_URL ]];
then
  RETRY_ATTEMPTS=20
  ATTEMPT=0
  job_failed_status="true"
  job_elapsed_time=0
  echo "Monitoring status of job ${JOB_URL}..."
  while [[ ${ATTEMPT} -lt ${RETRY_ATTEMPTS} ]]
  do
    echo "Waiting for job completion: ${ATTEMPT} of ${RETRY_ATTEMPTS}...$((ATTEMPT * 30)) seconds elapsed."
    sleep 30
    # /api/v2/jobs/1287/
    CURL_JCMD_OUTPUT=$(curl --location -k -s --request GET ${TOWER_SERVER}${JOB_URL} --header 'Authorization: Bearer ZbSxbpi7s452pCqd3LGcIP0cbd7LO6' --header 'Content-Type: application/json')
    CURL_RC=$?
    if [ ${CURL_RC} -ne 0 ]; then
      echo "Error: RC=${CURL_RC} Command output: ${CURL_JCMD_OUTPUT}"
      fatal ${CURL_RC} "curl exited with ${CURL_RC}, halting."
    fi

    job_status=`echo ${CURL_JCMD_OUTPUT} | /usr/local/bin/jq -r '.status'`
    if [[ ${job_status} = "successful" ]]; then
      echo "Job completion ${job_status} for job ${JOB_URL}"
      job_failed_status=`echo ${CURL_JCMD_OUTPUT} | /usr/local/bin/jq -r '.failed'`
      job_elapsed_time=`echo ${CURL_JCMD_OUTPUT} | /usr/local/bin/jq -r '.elapsed'`
      break
    elif [[ ${job_status} = "canceled" ]]; then
      echo "Job canceled for job ${JOB_URL}"
      job_failed_status=`echo ${CURL_JCMD_OUTPUT} | /usr/local/bin/jq -r '.failed'`
      break
    elif [[ ${job_status} = "running" ]]; then
      ATTEMPT=$((ATTEMPT + 1))
    else
      ATTEMPT=$((ATTEMPT + 1))
      echo "Job status ${job_status} for ${JOB_URL}"
    fi
  done

  if [[ ${job_failed_status} = "true" ]]; then
    echo ${CURL_JCMD_OUTPUT}
    fatal 1 "Failed to complete the job"
  else
    echo "Job ${JOB_URL} completed in ${job_elapsed_time} seconds"
  fi
else
  fatal 1 "Failed: No jobs started. Exiting."
fi

# End
