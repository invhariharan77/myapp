# Ansible Role: iis-deploy-s3
Download compressed web deployment package from s3 and deploy into iis website.

## Requirements

IIS is installed and website is set up.

## Role Variables

Available variables are listed below:
```
iis_deploy_s3_bucket_name: "dares-0207a297d8ac7a1f"
iis_deploy_s3_deployment_file: "CMRWebQA.zip" 
iis_deploy_s3_destination_path: "d:\\sites\\dares"
iis_deploy_s3_website_name: "dares"
```
## Dependencies

None.

## Example Playbook
```
    ---
    - name: Web server Setup
      hosts: webserver
      vars:
        iis_deploy_s3_bucket_name: "dares-0207a297d8ac7a1f"
        iis_deploy_s3_deployment_file: "CMRWebQA.zip" 
        iis_deploy_s3_destination_path: "d:\\sites\\dares"
        iis_deploy_s3_website_name: "dares"      
      roles:
        - role: cloudwatch-agent-config-windows
```