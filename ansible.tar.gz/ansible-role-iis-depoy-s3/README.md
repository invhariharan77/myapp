# Ansible Role: iis-deploy-s3
Download compressed web deployment package from s3 or Artifactory and deploy into iis website.

## Requirements

IIS is installed and website is set up.

## Role Variables

Available variables are listed below:
```
iis_deploy_s3_bucket_name: "dares-0207a297d8ac7a1f"
iis_deploy_s3_deployment_file: "CMRWebQA.zip" 
iis_deploy_s3_destination_path: "d:\\sites\\dares"
iis_deploy_s3_website_name: "dares"
artifactory_url_base: https://art.pmideep.com/artifactory/
artifactory_repo_name: "<product code>-generic-<environment>"
artifactory_username: "s-ds<environmentcode>-<product code>@pmintl.net"
artifactory_token: "AKCp8...<token>"
```
## Dependencies

None.

## Example Playbook with artifacts in s3
```
    ---
    - name: Web server Setup
      hosts: webserver
      vars:
        iis_deploy_s3_bucket_name: "dares-0207a297d8ac7a1f"
        iis_deploy_s3_deployment_file: "CMRWebQA.zip" 
        iis_deploy_s3_destination_path: "d:\\sites\\dares"
        iis_deploy_s3_website_name: "dares"      
      roles:
        - role: cloudwatch-agent-config-windows
```

## Example Playbook with artifacts in Artifactory
```
    ---
    - name: Web server Setup
      hosts: webserver
      vars:
        iis_deploy_s3_bucket_name: ""
        iis_deploy_s3_deployment_file: "CMRWebQA.zip" 
        iis_deploy_s3_destination_path: "d:\\sites\\dares"
        iis_deploy_s3_website_name: "dares"      
        artifactory_repo_name: "ffwd-generic-<environment>"
        artifactory_username: "s-dsq-<product code>@pmintl.net"
        artifactory_token: "AKCp8...<token>"
      roles:
        - role: cloudwatch-agent-config-windows
```

