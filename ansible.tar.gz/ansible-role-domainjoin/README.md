# Ansible Role: domain-join-windows

This ansible role joins windows ec2 instances in deep account to PMINTL.NET domain. Instances join the domain OU: "OU=PMI-```AWSaccountId```,OU=Servers,OU=AWS-DEEP,OU=INT-Cloud,OU=PMI,OU=Member Servers,DC=PMINTL,DC=NET". The role also adds the service account to the local Administrator group of the instance.

## PreRequisites

1. Service account is created for OU: "OU=PMI-```AWSaccountId```,OU=Servers,OU=AWS-DEEP,OU=INT-Cloud,OU=PMI,OU=Member Servers,DC=PMINTL,DC=NET"

2. [The Lamda function is created](https://source.app.pconnect.biz/projects/LANDSMD/repos/hostname-lambda/browse)  to uniquely determine hostname.

3. AWS secret is created with following keys:
```
{
  "service_account_user": "PMI\\service account id",
  "service_account_password": "service account password"
}
```
4. EC2 instance IAM role has following policy for lambda execution and secret read:

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "InvokeHostnameGenerationLambdafunction",
            "Effect": "Allow",
            "Action": "lambda:InvokeFunction",
            "Resource": "lambda arn"
        }
    ]
}
```
```
{
    "Version": "2012-10-17",
    "Statement": {
        "Effect": "Allow",
        "Action": "secretsmanager:GetSecretValue",
        "Resource": "secret arn"
    }
}
```

## Role Variables

Available variables are listed below:
```
    DomainJoin_HostnameLambdaName: hostnameassign
    DomainJoin_ServiceAccountSecretManagerId: ad/serviceaccount
    DomainJoin_HostnamePrefix: PMIEUIRLLMDD*
    DomainJoin_ServiceAccount: PMI\s-dsd-landsmd
```
## Dependencies

None.

## Example Playbook
```
    ---
    - name: Domain join
      hosts: webserver
      vars:
        DomainJoin_HostnameLambdaName: hostnameassign
        DomainJoin_ServiceAccountSecretManagerId: ad/serviceaccount
        DomainJoin_HostnamePrefix: PMIEUIRLLMDD*
        DomainJoin_ServiceAccount: PMI\s-dsd-landsmd
      roles:
        - role: domain-join-windows
```        