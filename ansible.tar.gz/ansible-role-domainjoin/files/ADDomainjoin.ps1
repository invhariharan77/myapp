Param(
    [string]$HostnameLambdaName,
    [string]$ServiceAccountSecretManagerId,
    [string]$HostnamePrefix
)

try {

    if ((gwmi win32_computersystem).partofdomain -eq $true) {
        Write-Output "The instance is already part of domain."
    } else {
   

        #Get service account credential from secret manager
        $secret = (Get-SECSecretValue -SecretId $ServiceAccountSecretManagerId).SecretString | ConvertFrom-Json
        $domainJoinUserName = $secret.service_account_user
        $domainJoinPassword = $secret.service_account_password
        $secpasswd = ConvertTo-SecureString $domainJoinPassword -AsPlainText -Force
        $creds = New-Object System.Management.Automation.PSCredential ($domainJoinUserName, $secpasswd)

        $Ec2InstanceId = (New-Object System.Net.WebClient).DownloadString("http://169.254.169.254/latest/meta-data/instance-id")
        $DEEPProductCode = (Get-EC2Tag -Filter @{ Name = "key"; Values = "ProductCode"}, @{ Name = "resource-id"; Values = $Ec2InstanceId}).Value
        $Ec2Environment = (Get-EC2Tag -Filter @{ Name = "key"; Values = "Environment"}, @{ Name = "resource-id"; Values = $Ec2InstanceId}).Value
        
        # determine the target OU
        $ou = "OU=" + $DEEPProductCode + "-" + $Ec2Environment + ",OU=Servers,OU=AWS-DEEP,OU=INT-Cloud,OU=PMI,OU=Member Servers,DC=PMINTL,DC=NET"
        $domain = "PMINTL.NET"

        $currentHostname = $env:ComputerName
        if ($currentHostname -like $HostnamePrefix) { 
            Write-Output "The instance is already renamed as:$currentHostname"
            Add-Computer -DomainName ${domain} -OUPath ${ou} -Credential ${creds}
        } else {
            #Get Hostname From Lambda Function
            $Result = Invoke-LMFunction -FunctionName $HostnameLambdaName
            $StreamReader = [System.IO.StreamReader]::new($Result.Payload)
            $NewHostname = $StreamReader.ReadToEnd().Replace("`"","") 
            Write-Output "New hostname:$NewHostname"
            Add-Computer -DomainName ${domain} -OUPath ${ou} -Credential ${creds} -NewName $NewHostname -ErrorAction Stop
        }
        Write-Output "The instance is domain joined successfuly"
       
    }

}
catch {
 Write-Output "Error when joining computer to domain"
 Write-Output $_
}