# Ansible Role: iis-setup

Installs IIS feature and create new website in iis. Also enables the new site for windows/forms authentication.

## Requirements

None.

## Role Variables

Available variables are listed below, along with default values (see `defaults/main.yml`):
```
iis_setup_website_name: "dares"
iis_setup_website_port: 80
iis_setup_website_path: "d:\\sites\\"
iis_setup_setup_auth: true
iis_setup_windows_auth: "1"
iis_setup_forms_auth: "1"
iis_setup_anonymous_auth: "0"
iis_setup_impersonate: "1"
```
## Dependencies

None.

## Example Playbook
```
    ---
    - name: Web server Setup
      hosts: webserver
      vars:
        iis_setup_website_name: "dares"
        iis_setup_website_port: 80
        iis_setup_website_path: "d:\\sites\\"
        iis_setup_setup_auth: true
        iis_setup_windows_auth: "1"
        iis_setup_forms_auth: "1"
        iis_setup_anonymous_auth: "0"
        iis_setup_impersonate: "1"        
      roles:
        - role: iis-setup
```

### Example Playbook to use Classic ASP for application pool

```

---
- name: Web server Setup
  hosts: win
  vars:
    iis_setup_website_name: "SPVisualLibrary"
    iis_setup_website_port: 80
    iis_setup_website_path: "D:\\sites\\"
    iis_setup_setup_auth: true
    iis_setup_windows_auth: "1"
    iis_setup_forms_auth: "1"
    iis_setup_anonymous_auth: "0"
    iis_setup_impersonate: "1"
    managedPipelineMode: "Classic"
    managedRuntimeVersion: ""
  roles:
    - role: ansible-role-iis-setup

Note : For non classic ASP applications values for managedPipelinemode and manageRuntimeVersion will be having default values populated
```

