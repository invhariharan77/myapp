param([string]$websitename=  $(throw "-websitename is required."),
      [int] $windowsauth = 0,
      [int] $formsauth = 0,
      [int] $anonymousauth = 0,
      [int] $impersonate = 0       
)

try
    {
        Add-WebConfigurationProperty "/system.web/authorization" -PSPath "IIS:\Sites\$websitename" -Name "." -value @{users='?'} -Type "deny"
        Add-WebConfigurationProperty "/system.web/authorization" -PSPath "IIS:\Sites\$websitename" -Name "." -value @{users='*'} -Type "allow"
        If ($windowsauth -eq 1 )
        {
            Set-WebConfigurationProperty -Filter '/system.webServer/security/authentication/windowsAuthentication' -Name Enabled -Value True -location IIS:\Sites\$websitename
        } 
        else {
            Set-WebConfigurationProperty -Filter '/system.webServer/security/authentication/windowsAuthentication' -Name Enabled -Value False -location IIS:\Sites\$websitename            
        }
        If ($anonymousauth -eq 1 )
        {
            Set-WebConfigurationProperty -Filter '/system.webServer/security/authentication/anonymousAuthentication' -Name Enabled -Value True -location IIS:\Sites\$websitename
        }
        else {
            Set-WebConfigurationProperty -Filter '/system.webServer/security/authentication/anonymousAuthentication' -Name Enabled -Value False -location IIS:\Sites\$websitename
        }
        if ($formsauth -eq 1 )
        {
            Set-WebConfiguration system.web/authentication "IIS:\sites\$websitename" -value @{mode='Forms'}
        }
        if ($impersonate -eq 1 )
        {
            $aspNetImpersonation = Get-WebConfigurationProperty -filter system.web/identity -name impersonate -location $websitename
	        if( $aspNetImpersonation.Value -eq $true ){
		        Write-Host "ASP.NET Impersonation is already enabled"
	        } else {
		        $appCmdFilePath = "$Env:SystemRoot\System32\inetsrv\appcmd.exe"
                & $appCmdFilePath set config "$websitename" -section:system.web/identity /impersonate:"True" 
	        }
        } 
    }
    catch
    {
        Write-Output "IIS Windows authentication configuration failed."
            
            $formatstring = "{0} : {1}`n{2}`n" +
                "    + CategoryInfo          : {3}`n" +
                "    + FullyQualifiedErrorId : {4}`n"
            $fields = $_.InvocationInfo.MyCommand.Name,
                      $_.ErrorDetails.Message,
                      $_.InvocationInfo.PositionMessage,
                      $_.CategoryInfo.ToString(),
                      $_.FullyQualifiedErrorId

            $formatstring -f $fields
            Write-Output ($formatstring -f $fields)
    }
